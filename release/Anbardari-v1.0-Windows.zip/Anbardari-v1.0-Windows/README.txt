Anbardari Inventory System v1.0 (Portable)

1. Copy this folder to your Windows PC
2. Double-click Start.bat (or شروع.bat)
3. Use the Persian menu buttons

No installation required.
Data is saved in the data folder.
